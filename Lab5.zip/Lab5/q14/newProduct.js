document.getElementById("productSubmitBtn").addEventListener("click",function(event){
    const productno = document.getElementById("productno").value;
    const qinstock = document.getElementById("qinstock").value;
    const pname = document.getElementById("pname").value;
    const unitprice = document.getElementById("unitprice").value;
    const datesupplied = document.getElementById("datesupplied").value;
    const supplier = document.getElementById("supplier").value;
    alert("Product no: " + String(productno) + " Quantity in Stock:" + String(qinstock) + " Product Name:" + String(pname) 
    + " Unit Price:" + String(unitprice)+ " Date supplied:" + String(datesupplied)+ " Supplier:" + String(supplier));
  });