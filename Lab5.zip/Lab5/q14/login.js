
document.getElementById("submitButton").addEventListener("click",function(event){
    const email = document.getElementById("email").value;
    console.log(email);
    const passw = document.getElementById("password").value;
    console.log(passw);
    const url = document.getElementById("url").value;
    console.log(url);
  });
  