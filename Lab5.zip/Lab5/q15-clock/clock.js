function currentDate (){
    let current = new Date();
    document.getElementById("time").innerHTML = current.getFullYear() + "-" + Number(current.getMonth()+1) +"-"+ current.getDate() 
    + " " +  pad(current.getHours()) +":"+ pad(current.getMinutes())+":"+ pad(current.getSeconds());
}
function pad(s) {
    if(s<10){
        return "0" + String(s);
    }
    return s;
}
currentDate();
setInterval(currentDate, 1);

