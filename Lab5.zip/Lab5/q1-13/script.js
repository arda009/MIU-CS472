{" use  strict" ;
// question 1
function max(x,y){
    if(x>y){
        return x;
    } else{
        return y;
    }
}
// question 2
function maxOfThree(x,y,z){
    if(x>y && x>z){
        return x;
    }
    else if(y>x && y>z){
        return y;
    } else{
        return z;
    }
} 

// question 3
function isVowel(c) {
    if(c == "a" || c ==="e" || c ==="i" || c==="o" || c==="u"){
        return true;
    }
    return false;
}

// question 4
function sum(x) {
    let result = 0;
    for (let i = 0; i < x.length; i++) {
        result += x[i];
    }
    return result;
}
function multiply(x) {
    let result = 1;
    for (let i = 0; i < x.length; i++) {
        result *= x[i];
    }
    return result;
}

// question 5
function reverse(a) {
    let result = "";
    for (let i = a.length-1; i >= 0; i--) {
        result += a[i];     
    }
    return result;
}

// question 6
function findLongestWord(words){
    let longestword = "";
    for (let i = 0; i < words.length; i++) {
        if(words[i].length > longestword.length){
            longestword = words[i];
        }
    }
    return longestword.length; 
} 

// question 7
function filterLongWords(array, i) {
    let a = [];
    for (let j = 0; j < array.length; j++) {
        if (array[j].length > i){
            a.push(array[j]);
        }
    }
    return a;
}

// question 8
function computeSumOfSquares (array){
    return array.map((x)=> x*x).reduce((prev, next)=>prev+next);
}

// question 9
function printOddNumbersOnly(array){
    array.filter((x)=>x%2 != 0).forEach(element => {
        console.log(element);
    });
}

// question 10
function computeSumOfSquaresOfEvensOnly(array){
    return array.filter((x)=>x%2 === 0).map((x)=>{
        return x*x;
    }).reduce((prev,next)=>{
        return prev + next;
    })
}

// question 11
function sum2(x) {
    return x.reduce((prev,next)=>prev+next);
}
function multiply2(x) {
    return x.reduce((prev,next)=>prev*next);
}

// question 12
function findSecondBiggest(array){
    return array.filter((x)=> {
        return x < array.reduce((prev,next)=> {
            if(prev>next){
                return prev;
            }
            return next;
        });
    }).reduce((prev,next)=> {
        if(prev>next){
            return prev;
        }
        return next;
    });
}

// question 13
function printFibo(n,a,b){
    let array = [a,b];
    for (let index = 0; index +1 < n; index++) {
        array.push(array[index] + array[index+1]);
    }
    array.forEach((element)=> console.log(element));
    return array;
}
}
